package com.hayden.limg_diary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimgDiaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimgDiaryApplication.class, args);
	}

}
