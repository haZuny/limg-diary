package com.hayden.limg_diary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimgDiaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
